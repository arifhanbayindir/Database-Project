-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 28 Ara 2023, 12:37:05
-- Sunucu sürümü: 8.0.31
-- PHP Sürümü: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `gastronova`
--

DELIMITER $$
--
-- Yordamlar
--
DROP PROCEDURE IF EXISTS `Barkod`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Barkod` (IN `Metin` VARCHAR(50))   SELECT ürünler.ürün_adi as "Ürün Adı",ürünler.ürün_marka as "Ürün Marka",
ürünler.barkod_numara as "Barkod",ürün_izleme.konum as "Konum" 
FROM ürünler,ürün_izleme
WHERE ürünler.ürün_id=ürün_izleme.ürün_id AND 
ürünler.barkod_numara=Metin$$

DROP PROCEDURE IF EXISTS `Bildirim`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Bildirim` (IN `y1` DATETIME, IN `y2` DATETIME)   SELECT ürünler.ürün_adi as "Ürün Adı" , ürünler.ürün_marka as 
"Ürün Marka" , ürünler.ürün_kategori as "Kategori" ,
tuketici_geri_bildirim.geri_bildirim_metni,tuketici_geri_bildirim.tarih
FROM ürünler,tuketici_geri_bildirim WHERE 
ürünler.ürün_id=tuketici_geri_bildirim.urun_id AND
tuketici_geri_bildirim.tarih BETWEEN y1 AND y2
ORDER BY tuketici_geri_bildirim.tarih$$

DROP PROCEDURE IF EXISTS `Guvenlik`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Guvenlik` (IN `Kod` VARCHAR(50))   SELECT ürünler.ürün_adi,ürünler.ürün_marka , 
güvenlik_etiket.güvenlik_kodu FROM ürünler,güvenlik_etiket 
WHERE ürünler.etiket_id=güvenlik_etiket.etiket_id AND 
güvenlik_etiket.güvenlik_kodu=Kod
ORDER BY güvenlik_etiket.güvenlik_kodu$$

DROP PROCEDURE IF EXISTS `Güvenlik etiketi aktive edilmemiş ürünleri ve etiket bilgilerini`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Güvenlik etiketi aktive edilmemiş ürünleri ve etiket bilgilerini` ()  NO SQL SELECT ürünler.ürün_adi as "Ürün Adı",ürünler.ürün_marka as "Ürün Marka",ürünler.ürün_kategori as "Kategori",
güvenlik_etiket.aktivasyon_tarih as aktivasyon_tarihleri ,güvenlik_etiket.güvenlik_kodu as güvenlik_kodu FROM 
ürünler,güvenlik_etiket WHERE
ürünler.etiket_id=güvenlik_etiket.etiket_id AND
güvenlik_etiket.aktivasyon_durum=0$$

DROP PROCEDURE IF EXISTS `id`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `id` ()   SELECT mağza.mağza_id, mağza.mağza_adi, mağza.mağza_adres, mağza.mağza_iletisim_bilgisi
FROM mağza
WHERE mağza.mağza_id = mağza_urun.mağza_id
AND mağza.mağza_adi LIKE '%v%'$$

DROP PROCEDURE IF EXISTS `Mağzalar ve stoklarında bulnan ürünler ve sayıları`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Mağzalar ve stoklarında bulnan ürünler ve sayıları` ()   SELECT mağza.mağza_adi as "Mağza Adı" , ürün_adi as "Ürün Adı" ,ürünler.ürün_kategori as "Kategori", mağza_urun.urun_stok as "Stok" FROM mağza_urun,mağza,ürünler WHERE ürünler.ürün_id=mağza_urun.urun_id AND mağza_urun.mağza_id=mağza.mağza_id$$

DROP PROCEDURE IF EXISTS `Mağzalarda Bulunan Ürün Sayıları`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Mağzalarda Bulunan Ürün Sayıları` ()   SELECT COUNT(ürünler.ürün_id) as "Ürün Sayısı", mağza.mağza_adi as "Mağza Adı" FROM ürünler,mağza,mağza_urun WHERE ürünler.ürün_id=mağza_urun.urun_id AND mağza.mağza_id=mağza_urun.mağza_id GROUP BY mağza.mağza_id$$

DROP PROCEDURE IF EXISTS `Stok`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Stok` (IN `Sayı` INT, IN `Sayı2` INT)   SELECT ürünler.ürün_adi as "Ürün Adı", ürünler.ürün_marka as 
"Marka",ürünler.ürün_kategori as "Kategori",
mağza_urun.urun_stok as "Stok" FROM ürünler,mağza_urun WHERE
ürünler.ürün_id=mağza_urun.urun_id AND mağza_urun.urun_stok 
BETWEEN Sayı AND Sayı2  ORDER BY mağza_urun.urun_stok ASC$$

DROP PROCEDURE IF EXISTS `Üretici ürünlerinin ne kadar bildirim almış`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Üretici ürünlerinin ne kadar bildirim almış` ()   SELECT üreticiler.üretici_adi as "Üretici Adı" ,COUNT(tuketici_geri_bildirim.geri_bildirim_id) as "Bildirim Sayısı" FROM ürünler,üreticiler,tuketici_geri_bildirim WHERE 
üreticiler.üretici_id=ürünler.üretici_id AND ürünler.ürün_id=tuketici_geri_bildirim.urun_id GROUP BY üreticiler.üretici_adi$$

DROP PROCEDURE IF EXISTS `Ürün Kategorilerinin ortalama izlenme durumları`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Ürün Kategorilerinin ortalama izlenme durumları` ()   SELECT ürünler.ürün_kategori as "Kategoriler",ROUND(AVG(ürün_izleme.nem)) as "Ortlama Nem",ROUND(AVG(ürün_izleme.sıcaklık)) as "Ortlama Sıcaklık" FROM ürünler,ürün_izleme WHERE ürünler.ürün_id=ürün_izleme.ürün_id GROUP BY ürünler.ürün_kategori$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dağıtıcılar`
--

DROP TABLE IF EXISTS `dağıtıcılar`;
CREATE TABLE IF NOT EXISTS `dağıtıcılar` (
  `dağıtıcı_id` int NOT NULL AUTO_INCREMENT,
  `dağıtıcı_adi` varchar(100) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `dağıtıcı_adresi` varchar(200) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `dağıtıcı_iletişim` varchar(100) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  PRIMARY KEY (`dağıtıcı_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `dağıtıcılar`
--

INSERT INTO `dağıtıcılar` (`dağıtıcı_id`, `dağıtıcı_adi`, `dağıtıcı_adresi`, `dağıtıcı_iletişim`) VALUES
(1, 'FreshSupply', 'Amasya,Dağıtım Sk. No: 789', 'info@freshsupply.com'),
(2, 'FastLogistics', 'Aydın,Hızlı Lojistik Cad. 12', 'info@fastlogistics.com'),
(3, 'GreenDelivery', 'Muğla,Yeşil Sk. No: 456', 'info@greendelivery.com'),
(4, 'NatureLogistics', 'İzmir,Doğal Lojistik Cad. 56', 'info@naturelogistics.com'),
(5, 'FreshLogistics', 'İstanbul,Taze Lojistik Sk. 78', 'info@freshlogistics.com'),
(6, 'EcoDelivery', 'Hatay,Ekolojik Dağıtım Sk. 112', 'info@ecodelivery.com'),
(7, 'ExpressCargo', 'Antalya,Hızlı Kargo Cad. 34', 'info@expresscargo.com'),
(8, 'SwiftTransport', 'Balıkesir,Hızlı Taşıma Cad. 90', 'info@swifttransport.com'),
(9, 'OrganicFreight', 'Kayseri,Organik Kargo Sk. 156', 'info@organicfreight.com'),
(10, 'FreshHarbor', 'İzmir,Taze Liman SK.200', 'info@freshharbor.com');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dağıtıcı_urunler`
--

DROP TABLE IF EXISTS `dağıtıcı_urunler`;
CREATE TABLE IF NOT EXISTS `dağıtıcı_urunler` (
  `urun_id` int DEFAULT NULL,
  `dağıtıcı_id` int DEFAULT NULL,
  KEY `fk_dağıtıcı_urun` (`urun_id`),
  KEY `fk_dagıtıcı` (`dağıtıcı_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `dağıtıcı_urunler`
--

INSERT INTO `dağıtıcı_urunler` (`urun_id`, `dağıtıcı_id`) VALUES
(1, 3),
(2, 1),
(3, 10),
(4, 9),
(5, 2),
(6, 8),
(7, 7),
(8, 6),
(9, 5),
(10, 4);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ekleme_sonrası_bildirim`
--

DROP TABLE IF EXISTS `ekleme_sonrası_bildirim`;
CREATE TABLE IF NOT EXISTS `ekleme_sonrası_bildirim` (
  `toplam_bildirim` int DEFAULT NULL,
  `zaman` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `ekleme_sonrası_bildirim`
--

INSERT INTO `ekleme_sonrası_bildirim` (`toplam_bildirim`, `zaman`) VALUES
(12, '2023-12-27 15:31:45'),
(13, '2023-12-27 15:32:53');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `güncelleme_öncesi_izlenme`
--

DROP TABLE IF EXISTS `güncelleme_öncesi_izlenme`;
CREATE TABLE IF NOT EXISTS `güncelleme_öncesi_izlenme` (
  `izleme_id` int DEFAULT NULL,
  `nem` int DEFAULT NULL,
  `sıcaklık` int DEFAULT NULL,
  `ürün_id` int DEFAULT NULL,
  `izlenme_tarih` datetime DEFAULT NULL,
  `güncel_zamanı` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `güncelleme_öncesi_izlenme`
--

INSERT INTO `güncelleme_öncesi_izlenme` (`izleme_id`, `nem`, `sıcaklık`, `ürün_id`, `izlenme_tarih`, `güncel_zamanı`) VALUES
(8, 15, 70, 6, '2023-07-24 09:00:00', '2023-12-27 01:31:19'),
(2, 60, 22, 2, '2023-01-10 09:10:35', '2023-12-27 01:32:26'),
(1, 56, 21, 1, '2023-01-15 14:45:00', '2023-12-27 01:32:46');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `güvenlik_etiket`
--

DROP TABLE IF EXISTS `güvenlik_etiket`;
CREATE TABLE IF NOT EXISTS `güvenlik_etiket` (
  `etiket_id` int NOT NULL AUTO_INCREMENT,
  `aktivasyon_tarih` datetime DEFAULT NULL,
  `aktivasyon_durum` tinyint(1) DEFAULT NULL,
  `güvenlik_kodu` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  PRIMARY KEY (`etiket_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `güvenlik_etiket`
--

INSERT INTO `güvenlik_etiket` (`etiket_id`, `aktivasyon_tarih`, `aktivasyon_durum`, `güvenlik_kodu`) VALUES
(1, '2023-01-20 12:00:00', 1, 'ABC123'),
(2, '2023-01-27 16:30:00', 0, 'XYZ789'),
(3, '2023-05-08 20:10:00', 0, 'TYBW53'),
(4, '2024-04-01 14:40:00', 1, 'ZNRI30'),
(5, '2024-03-05 08:20:00', 1, 'KSFC62'),
(6, '2023-09-11 08:35:15', 1, 'GRQ7H2'),
(7, '2023-02-21 11:09:35', 1, 'NC6W9P'),
(8, '2023-04-21 15:09:00', 0, 'DS0F1E'),
(9, '0000-00-00 00:00:00', 0, 'BT3Y74'),
(10, '2023-07-13 16:40:20', 0, 'PJ6Q1U');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mağza`
--

DROP TABLE IF EXISTS `mağza`;
CREATE TABLE IF NOT EXISTS `mağza` (
  `mağza_id` int NOT NULL AUTO_INCREMENT,
  `mağza_adi` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `mağza_adres` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `iletişim_bilgisi` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  PRIMARY KEY (`mağza_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `mağza`
--

INSERT INTO `mağza` (`mağza_id`, `mağza_adi`, `mağza_adres`, `iletişim_bilgisi`) VALUES
(1, 'FreshMart', 'İzmir,Merkez Sk. No: 567', 'info@martfresh.com'),
(2, 'HealthyCorner', 'Muğla,Sağlıklı Cad. 34', 'info@corhealthy.com'),
(3, 'VitalVillage', 'Aydın,Vital Köy Sk. 134', 'info@vitalvillage.com'),
(4, 'PureProduce', 'Ankara,Saf Ürünler Cad. 156', 'info@pureproduce.com'),
(5, 'EcoMarket', 'Kayseri,Ekolojik Market Sk. 90', 'info@ecomarket.com'),
(6, 'FreshBasket', 'Bursa,Taze Sepet Sk. 56', 'info@freshbasket.com'),
(7, 'GreenGrocery', 'İzmir,Yeşil Market Sk. No: 789', 'info@greengrocery.com'),
(8, 'OrganicHarvest', 'Balıkesir,Organik Hasat Cad. 12', 'info@organicharvest.com'),
(9, 'NaturalNook', 'Hatay,Doğal Nokta Cad. 200', 'info@naturalnook.com'),
(10, 'HealthHub', 'Aydın,Sağlık Noktası Cad. 112', 'info@healthhub.com');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mağza_dağıtıcı`
--

DROP TABLE IF EXISTS `mağza_dağıtıcı`;
CREATE TABLE IF NOT EXISTS `mağza_dağıtıcı` (
  `mağza_id` int DEFAULT NULL,
  `dağıtıcı_id` int DEFAULT NULL,
  KEY `fk_mağza_dagıt` (`dağıtıcı_id`),
  KEY `fk_mağza` (`mağza_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `mağza_dağıtıcı`
--

INSERT INTO `mağza_dağıtıcı` (`mağza_id`, `dağıtıcı_id`) VALUES
(1, 4),
(2, 3),
(3, 2),
(4, 1),
(5, 9),
(6, 5),
(7, 10),
(8, 8),
(9, 6),
(10, 7);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mağza_urun`
--

DROP TABLE IF EXISTS `mağza_urun`;
CREATE TABLE IF NOT EXISTS `mağza_urun` (
  `mağza_id` int DEFAULT NULL,
  `urun_id` int DEFAULT NULL,
  `urun_stok` int DEFAULT NULL,
  KEY `fk_mağza_urun` (`urun_id`),
  KEY `fk_urun_magza` (`mağza_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `mağza_urun`
--

INSERT INTO `mağza_urun` (`mağza_id`, `urun_id`, `urun_stok`) VALUES
(1, 8, 1100),
(2, 4, 800),
(3, 3, 5000),
(4, 2, 3000),
(3, 9, 2500),
(6, 1, 7000),
(3, 10, 1000),
(8, 7, 1500),
(4, 6, 3800),
(10, 5, 2300);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `silinen_ürünler`
--

DROP TABLE IF EXISTS `silinen_ürünler`;
CREATE TABLE IF NOT EXISTS `silinen_ürünler` (
  `ürün_id` int DEFAULT NULL,
  `ürün_adı` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `ürün_marka` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `üretim_tarihi` datetime DEFAULT NULL,
  `silinme_tarihi` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `silinen_ürünler`
--

INSERT INTO `silinen_ürünler` (`ürün_id`, `ürün_adı`, `ürün_marka`, `üretim_tarihi`, `silinme_tarihi`) VALUES
(9, 'Peynirli Pizza', 'Lezzet Pizza', '2023-02-20 00:00:00', '2023-12-27 18:44:58'),
(10, 'Badem Ezmesi', 'Doğal Tatlar', '2023-10-03 00:00:00', '2023-12-27 18:44:51'),
(10, 'Badem Ezmesi', 'Doğal Tatlar', '2023-10-03 00:00:00', '2023-12-27 18:44:55'),
(11, 'Kepekli Makarna', 'Fit Gurme', '2023-03-12 00:00:00', '2023-12-26 23:52:56'),
(11, 'Psdvksdvs', 'vsnvsdjvnsj', '2023-12-19 00:00:00', '2023-12-27 18:46:09'),
(12, 'Fırın Tavuk Kanadı', 'Lezzet Kanat', '2023-08-12 00:00:00', '2023-12-26 23:51:58');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tuketici_geri_bildirim`
--

DROP TABLE IF EXISTS `tuketici_geri_bildirim`;
CREATE TABLE IF NOT EXISTS `tuketici_geri_bildirim` (
  `geri_bildirim_id` int NOT NULL AUTO_INCREMENT,
  `geri_bildirim_metni` varchar(255) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `tarih` datetime DEFAULT NULL,
  `tuketici_adi` varchar(50) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `urun_id` int DEFAULT NULL,
  PRIMARY KEY (`geri_bildirim_id`),
  KEY `fk_bildirim` (`urun_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `tuketici_geri_bildirim`
--

INSERT INTO `tuketici_geri_bildirim` (`geri_bildirim_id`, `geri_bildirim_metni`, `tarih`, `tuketici_adi`, `urun_id`) VALUES
(1, 'Elma çok taze ve lezzetli!', '2023-01-21 10:30:00', 'Azra Deri', 1),
(2, 'Ekmek çok lezzetli, teşekkürler!', '2023-01-17 14:20:00', 'Mert Yılmaz', 2),
(3, 'Deniz Ürünleriniz tadı bu sefer umduğum gibi değildi!', '2023-11-14 20:30:00', 'Kutay Fenk', 3),
(4, 'Kahvaltılıklarınız çok lezzetliydi , teşşekürler!', '2023-04-16 09:40:00', 'Cerin Latıy', 4),
(5, 'Süt ve Süt Ürünleriniz eski tatıdı kalmamış artık,teşşekürler', '2023-07-16 15:10:00', 'Lare Uban', 5),
(6, 'Ürünlerinizin tadı eskisi gibi değildi.', '2023-04-23 00:00:00', 'Ahmet Cenk', 4),
(7, 'Badem Ezmeniz çok lezzetliydi teşekkürler.', '2023-04-15 00:00:00', 'Lerin Fert', 10),
(8, 'Balıklarınız tadı benim içimi heyecanlandırdı kısaca güzeldi.', '2023-05-29 00:00:00', 'Nedit Sert', 3),
(9, 'Sütlerinizin tadını çok beğendim güzel olmuş', '2023-09-24 00:00:00', 'Hira Abır', 5),
(10, 'Pizzanızın tadı gayet güzeldi.', '2023-03-05 00:00:00', 'Doruk Aser', 9),
(11, 'Kahvaltılıklarınızı çok beğendim tadı çok beğendim', '2023-06-17 00:00:00', 'Ahmet Guru', 4),
(12, 'Balıklar çok güzel.', '2023-06-20 00:00:00', 'Ahmet Tetir', 3),
(13, 'Meyvelerinizin tadını çok beğendim .', '2023-11-30 00:00:00', 'Ceren Bayar', 1);

--
-- Tetikleyiciler `tuketici_geri_bildirim`
--
DROP TRIGGER IF EXISTS `ekleme_sonrası_bildirim`;
DELIMITER $$
CREATE TRIGGER `ekleme_sonrası_bildirim` AFTER INSERT ON `tuketici_geri_bildirim` FOR EACH ROW INSERT INTO ekleme_sonrası_bildirim 
VALUES((SELECT COUNT(tuketici_geri_bildirim.geri_bildirim_id) as "Toplam Bildirim"  FROM tuketici_geri_bildirim),now())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `üreticiler`
--

DROP TABLE IF EXISTS `üreticiler`;
CREATE TABLE IF NOT EXISTS `üreticiler` (
  `üretici_id` int NOT NULL AUTO_INCREMENT,
  `üretici_adi` varchar(50) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `üretici_adresi` varchar(100) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `üretici_iletişim` varchar(50) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  PRIMARY KEY (`üretici_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `üreticiler`
--

INSERT INTO `üreticiler` (`üretici_id`, `üretici_adi`, `üretici_adresi`, `üretici_iletişim`) VALUES
(1, 'FruitCo', 'Bursa,Meyve Sok.No:123', 'info@fruitco.com'),
(2, 'GrainBakery', 'Amasya,Ekmek Cad.No:456', 'info@grainbakery.com'),
(3, 'Lezzet Gıda', 'İzmir,Gıda Caddesi No:43', 'info@lezzetgida.com'),
(4, 'Sağlıklı Tatlar', 'Aydın,Sağlık Sokak No:11', 'info@sagliklitat.com'),
(5, 'Organik Lezzetler', 'Muğla,Organik Mahalle No:78', 'info@lezzet_organik.com'),
(6, 'FreshHavert', 'Kütahya,Fresh Cad. No:707', 'info@freshharvest.com'),
(7, 'OrganicHarbor', 'Hatay,Organik Liman Sok. No: 606', 'info@organicharbor.com'),
(8, 'FarmersChoice', 'İstanbul,Çiftçinin Seçimi Cad. No: 707', 'info@farmerschoice.com'),
(9, 'PureProduce', 'Edirne,Saf Ürünler Cad. No: 303', 'info@pureproduce.com'),
(10, 'HealthyHarvest', 'Sinop,Sağlık Cad. No: 101', 'info@healthyharvest.com'),
(11, 'BioBites', 'Rize,Biyo Lezzet Cad. No: 404', 'info@biobites.com'),
(12, 'GreenFarms', 'Adana,Tarla Cad. No: 789', 'info@greenfarms.com'),
(13, 'DeliciousCrops', 'Gaziantep,Lezzetli Mahsuller Sok. No: 808', 'info@deliciouscrops.com');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ürünler`
--

DROP TABLE IF EXISTS `ürünler`;
CREATE TABLE IF NOT EXISTS `ürünler` (
  `ürün_id` int NOT NULL AUTO_INCREMENT,
  `ürün_adi` varchar(100) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `ürün_marka` varchar(100) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `ürün_kategori` varchar(50) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `üretim_tarihi` date DEFAULT NULL,
  `son_kullanma_tarihi` date DEFAULT NULL,
  `barkod_numara` varchar(50) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `üretici_id` int DEFAULT NULL,
  `etiket_id` int DEFAULT NULL,
  PRIMARY KEY (`ürün_id`),
  KEY `fk_urun_üretici` (`üretici_id`),
  KEY `fk_etiket` (`etiket_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `ürünler`
--

INSERT INTO `ürünler` (`ürün_id`, `ürün_adi`, `ürün_marka`, `ürün_kategori`, `üretim_tarihi`, `son_kullanma_tarihi`, `barkod_numara`, `üretici_id`, `etiket_id`) VALUES
(1, 'Elma', 'FreshFruit', 'Meyve', '2023-01-15', '2023-02-15', '123456789', 1, 1),
(2, 'Tam Buğday Ekmeği', 'HealthyBread', 'Ekmek', '2023-01-10', '2023-01-20', '987654321', 2, 2),
(3, 'Deniz Ürünleri Mix', 'Lezzet Denizi', 'Deniz Ürünleri', '2023-05-12', '2023-11-12', '345678901', 3, 3),
(4, 'Ev Yapımı Reçel', 'Anne Mutfak', 'Kahvaltılıklar', '2023-04-05', '2024-04-05', '567890123', 4, 4),
(5, 'Beyaz Peynir', 'Sütün Lezzeti', 'Süt ve Süt Ürünleri', '2023-03-10', '2023-07-15', '456789012', 5, 5),
(6, 'Hindistancevizi Yoğurt', 'Sağlıklı Süt', 'Süt ve Süt Ürünleri', '2023-09-20', '2023-10-20', '303132333', 6, 5),
(7, 'Mango Smoothie', 'Taze Meyve', 'İçecekler', '2023-06-01', '2023-09-01', '181920212', 7, 6),
(8, 'Ev Yapımı Ballı Granola', 'Sağlıklı Atıştırmalık', 'Kahvaltılıklar', '2023-04-10', '2023-10-10', '101112131', 8, 4),
(9, 'Peynirli Pizza', 'Lezzet Pizza', 'Fast Food', '2023-02-20', '2023-08-20', '111222333', 9, 7),
(10, 'Badem Ezmesi', 'Doğal Tatlar', 'Kahvaltılıklar', '2023-10-03', '2024-04-03', '343536373', 10, 4);

--
-- Tetikleyiciler `ürünler`
--
DROP TRIGGER IF EXISTS `silinen_ürünler`;
DELIMITER $$
CREATE TRIGGER `silinen_ürünler` BEFORE DELETE ON `ürünler` FOR EACH ROW INSERT silinen_ürünler VALUES(old.ürün_id,old.ürün_adi,
old.ürün_marka,old.üretim_tarihi,now())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ürün_izleme`
--

DROP TABLE IF EXISTS `ürün_izleme`;
CREATE TABLE IF NOT EXISTS `ürün_izleme` (
  `izleme_id` int NOT NULL AUTO_INCREMENT,
  `nem` decimal(10,0) DEFAULT NULL,
  `sıcaklık` decimal(10,0) DEFAULT NULL,
  `konum` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `izleme_tarih` datetime DEFAULT NULL,
  `ürün_id` int DEFAULT NULL,
  PRIMARY KEY (`izleme_id`),
  KEY `fk_izleme` (`ürün_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `ürün_izleme`
--

INSERT INTO `ürün_izleme` (`izleme_id`, `nem`, `sıcaklık`, `konum`, `izleme_tarih`, `ürün_id`) VALUES
(1, '27', '8', 'Depo A', '2023-01-15 14:45:00', 1),
(2, '35', '12', 'Nakliye Aracı', '2023-01-10 09:10:35', 2),
(3, '4', '-15', 'Soğuk Hava Deposu', '2023-05-12 11:20:10', 3),
(4, '20', '40', 'Depo B', '2023-04-05 08:15:10', 4),
(5, '19', '46', 'Depo C', '2023-03-10 13:50:40', 5),
(6, '22', '50', 'Vital Village', '2023-01-18 16:20:00', 7),
(7, '23', '53', 'EconMarket Taze Ürün Bölüm', '2023-03-25 14:15:00', 9),
(8, '18', '52', 'Depo C', '2023-07-24 09:00:00', 6),
(9, '2', '-20', 'Soğuk Hava Deposu', '2023-04-10 13:10:00', 10),
(10, '26', '48', 'Depo Girişi', '2023-11-30 08:15:00', 8);

--
-- Tetikleyiciler `ürün_izleme`
--
DROP TRIGGER IF EXISTS `güncelleme_öncesi_izlenme`;
DELIMITER $$
CREATE TRIGGER `güncelleme_öncesi_izlenme` BEFORE UPDATE ON `ürün_izleme` FOR EACH ROW INSERT INTO güncelleme_öncesi_izlenme VALUES(old.izleme_id,
old.nem,old.sıcaklık,old.ürün_id,old.izleme_tarih,now())
$$
DELIMITER ;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `dağıtıcı_urunler`
--
ALTER TABLE `dağıtıcı_urunler`
  ADD CONSTRAINT `fk_dagıtıcı` FOREIGN KEY (`dağıtıcı_id`) REFERENCES `dağıtıcılar` (`dağıtıcı_id`),
  ADD CONSTRAINT `fk_dağıtıcı_urun` FOREIGN KEY (`urun_id`) REFERENCES `ürünler` (`ürün_id`);

--
-- Tablo kısıtlamaları `mağza_dağıtıcı`
--
ALTER TABLE `mağza_dağıtıcı`
  ADD CONSTRAINT `fk_mağza` FOREIGN KEY (`mağza_id`) REFERENCES `mağza` (`mağza_id`),
  ADD CONSTRAINT `fk_mağza_dagıt` FOREIGN KEY (`dağıtıcı_id`) REFERENCES `dağıtıcılar` (`dağıtıcı_id`);

--
-- Tablo kısıtlamaları `mağza_urun`
--
ALTER TABLE `mağza_urun`
  ADD CONSTRAINT `fk_mağza_urun` FOREIGN KEY (`urun_id`) REFERENCES `ürünler` (`ürün_id`),
  ADD CONSTRAINT `fk_urun_magza` FOREIGN KEY (`mağza_id`) REFERENCES `mağza` (`mağza_id`);

--
-- Tablo kısıtlamaları `tuketici_geri_bildirim`
--
ALTER TABLE `tuketici_geri_bildirim`
  ADD CONSTRAINT `fk_bildirim` FOREIGN KEY (`urun_id`) REFERENCES `ürünler` (`ürün_id`);

--
-- Tablo kısıtlamaları `ürünler`
--
ALTER TABLE `ürünler`
  ADD CONSTRAINT `fk_etiket` FOREIGN KEY (`etiket_id`) REFERENCES `güvenlik_etiket` (`etiket_id`),
  ADD CONSTRAINT `fk_urun_üretici` FOREIGN KEY (`üretici_id`) REFERENCES `üreticiler` (`üretici_id`);

--
-- Tablo kısıtlamaları `ürün_izleme`
--
ALTER TABLE `ürün_izleme`
  ADD CONSTRAINT `fk_izleme` FOREIGN KEY (`ürün_id`) REFERENCES `ürünler` (`ürün_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
